<?php
$dbCon = mysqli_connect("localhost", "root", "realmadrid", "mqst") 	or die('error');
?>
